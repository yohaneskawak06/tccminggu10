<?php

echo time();

phpinfo();
